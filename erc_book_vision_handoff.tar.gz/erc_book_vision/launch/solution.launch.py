"""Member 1 perception launch; include it from the team's full solution launch."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('shelf_column_number', default_value='2'),
        DeclareLaunchArgument('book_colour', default_value='red'),
        DeclareLaunchArgument('row_order', default_value='top_to_bottom'),
        DeclareLaunchArgument('evidence_dir', default_value='erc_images'),
        DeclareLaunchArgument('save_evidence', default_value='true'),
        Node(package='erc_book_vision', executable='book_vision.py',
             name='book_vision', output='screen', parameters=[{
                 'use_sim_time': True,
                 'shelf_column_number': ParameterValue(LaunchConfiguration('shelf_column_number'), value_type=int),
                 'book_colour': ParameterValue(LaunchConfiguration('book_colour'), value_type=str),
                 'row_order': ParameterValue(LaunchConfiguration('row_order'), value_type=str),
                 'evidence_dir': ParameterValue(LaunchConfiguration('evidence_dir'), value_type=str),
                 'save_evidence': ParameterValue(LaunchConfiguration('save_evidence'), value_type=bool)}]),
    ])
