#!/usr/bin/env python3
"""Member 1 live vision, scoring topics, and Member 4 pixel handoff."""
from pathlib import Path
from datetime import datetime, timezone
import json
import time
import uuid

import cv2
import rclpy
from rclpy.node import Node
from rclpy.clock import Clock, ClockType
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import String, Int32
from cv_bridge import CvBridge
from ament_index_python.packages import get_package_share_directory
from vision_core import load_templates, detect_digits, column_region, find_books
from vision_logic import Confirmation, infer_row


class BookVision(Node):
    def __init__(self):
        super().__init__('book_vision')
        for name, value in [('shelf_column_number', 2), ('book_colour', 'red'),
                            ('row_order', 'top_to_bottom'), ('evidence_dir', 'erc_images'),
                            ('save_evidence', True), ('stale_timeout', 5.0)]:
            self.declare_parameter(name, value)
        self.target = self.get_parameter('shelf_column_number').value
        self.colour = self.get_parameter('book_colour').value.lower()
        self.row_order = self.get_parameter('row_order').value
        self.timeout = self.get_parameter('stale_timeout').value
        self.save_enabled = self.get_parameter('save_evidence').value
        if self.target not in range(1, 6) or self.colour not in ('red', 'blue', 'green', 'yellow'):
            raise ValueError('Use shelf_column_number 1-5 and red/blue/green/yellow')
        if self.row_order not in ('top_to_bottom', 'bottom_to_top') or self.timeout <= 0:
            raise ValueError('Invalid row_order or stale_timeout')
        # Inputs are fixed per process. Relaunch for a new requested book.
        from rcl_interfaces.msg import SetParametersResult
        protected = {'shelf_column_number', 'book_colour', 'row_order', 'evidence_dir',
                     'save_evidence', 'stale_timeout'}
        self.add_on_set_parameters_callback(lambda params: SetParametersResult(
            successful=not any(p.name in protected for p in params),
            reason='Relaunch the vision node to change its request/settings'))
        templates = Path(get_package_share_directory('erc_description')) / 'models/number_marker/textures'
        self.templates = load_templates(templates)
        self.bridge = CvBridge()
        self.column_check, self.book_check, self.row_check = Confirmation(), Confirmation(), Confirmation()
        self.last_stamp, self.last_payload, self.last_text = None, None, None
        self.last_frame = time.monotonic()
        self.run_id = uuid.uuid4().hex[:10]
        self.saved, self.save_retry = set(), {}
        self.evidence_dir = Path(self.get_parameter('evidence_dir').value).expanduser().resolve()
        self.images = self.create_publisher(Image, '/book_vision/image', 1)
        self.detections = self.create_publisher(String, '/book_vision/detection', 1)
        self.column_pub = self.create_publisher(Int32, '/erc/shelf_column_identification', 10)
        self.row_pub = self.create_publisher(Int32, '/erc/shelf_row_identification', 10)
        self.sub = self.create_subscription(Image,
            '/head_front_camera/head_front_camera/color/image_raw',
            self.process, qos_profile_sensor_data)
        self.wall_clock = Clock(clock_type=ClockType.STEADY_TIME)
        self.timer = self.create_timer(1.0, self.watchdog, clock=self.wall_clock)
        self.get_logger().info(
            f'Member 1 ready: column {self.target}, {self.colour}. '
            f'Rows: {self.row_order}. Evidence: {self.evidence_dir}')

    def reset(self):
        for check in (self.column_check, self.book_check, self.row_check):
            check.reset()

    def publish_payload(self, payload):
        self.last_payload = payload
        self.detections.publish(String(data=json.dumps(payload, allow_nan=False)))

    def report(self, text):
        if text != self.last_text:
            self.get_logger().info(text)
            self.last_text = text

    def watchdog(self):
        if time.monotonic()-self.last_frame <= self.timeout:
            return
        self.reset()
        if self.last_payload:
            payload = dict(self.last_payload)
            payload.update(valid=False, row_valid=False, shelf_row=None,
                           pixel_center=None, bbox_xywh=None, reason='stale_camera')
            self.publish_payload(payload)
        self.report('No fresh camera frame; detection invalidated')

    def save_image(self, kind, frame, msg, box, description):
        if not self.save_enabled or kind in self.saved:
            return
        now = time.monotonic()
        if now < self.save_retry.get(kind, 0):
            return
        try:
            self.evidence_dir.mkdir(parents=True, exist_ok=True)
            output = frame.copy()
            x, y, w, h = box
            cv2.rectangle(output, (x, y), (x+w-1, y+h-1), (0, 210, 0), 1)
            stamp = msg.header.stamp
            utc = datetime.now(timezone.utc).isoformat(timespec='milliseconds')
            output = cv2.copyMakeBorder(output, 0, 50, 0, 0,
                cv2.BORDER_CONSTANT, value=(255, 255, 255))
            for index, text in enumerate([description,
                    f'Camera stamp {stamp.sec}.{stamp.nanosec:09d} | UTC {utc}']):
                cv2.putText(output, text, (5, output.shape[0]-32+index*20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, (0, 0, 0), 1)
            filename = (f'{self.run_id}_column{self.target}_{self.colour}_{kind}_'
                        f'{stamp.sec}_{stamp.nanosec:09d}.png')
            if not cv2.imwrite(str(self.evidence_dir/filename), output):
                raise OSError('OpenCV could not write image')
            self.saved.add(kind)
            self.get_logger().info(f'Saved {kind} evidence: {self.evidence_dir/filename}')
        except Exception as error:
            self.save_retry[kind] = now+10
            self.get_logger().error(f'Evidence save failed (will retry): {error}')

    def process(self, msg):
        stamp = (msg.header.stamp.sec, msg.header.stamp.nanosec)
        if stamp == self.last_stamp:
            return
        if self.last_stamp and stamp < self.last_stamp:
            self.reset()
            self.saved.clear()
            self.run_id = uuid.uuid4().hex[:10]
        if time.monotonic()-self.last_frame > self.timeout:
            self.reset()
        self.last_stamp, self.last_frame = stamp, time.monotonic()
        payload = {
            'schema_version': 1, 'run_id': self.run_id,
            'header': {'stamp': {'sec': stamp[0], 'nanosec': stamp[1]},
                       'frame_id': msg.header.frame_id},
            'image_width': int(msg.width), 'image_height': int(msg.height),
            'shelf_column_number': self.target, 'book_colour': self.colour,
            'valid': False, 'pixel_center': None, 'bbox_xywh': None,
            'column_bbox_xywh': None, 'shelf_row': None, 'row_valid': False,
            'row_order': self.row_order, 'label_similarity': None,
            'reason': 'waiting_for_labels'}
        output = None
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            output = frame.copy()
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            markers = detect_digits(hsv, self.templates)
            region = column_region(markers, self.target, frame.shape[1], frame.shape[0])
            for digit, x, y, w, h, score in markers:
                cv2.rectangle(output, (x, y), (x+w-1, y+h-1), (0, 180, 0), 1)
            if region is None:
                self.reset()
            else:
                left, top, right, bottom = region
                marker = next(m for m in markers if m[0] == self.target)
                # Include the requested number marker in the column evidence.
                column_box = (left, marker[2], right-left, bottom-marker[2])
                payload['column_bbox_xywh'] = list(map(int, column_box))
                payload['label_similarity'] = float(marker[5])
                order = tuple(m[0] for m in markers)
                column_stable = self.column_check.update(order, column_box)
                cv2.rectangle(output, (left, top), (right-1, bottom-1), (255, 180, 0), 1)
                if column_stable:
                    self.column_pub.publish(Int32(data=self.target))
                    self.save_image('column', frame, msg, column_box,
                                    f'Requested shelf column {self.target}')
                all_books = {colour: find_books(hsv, region, colour)
                             for colour in ('red', 'green', 'blue', 'yellow')}
                candidates = all_books[self.colour]
                if len(candidates) != 1:
                    self.book_check.reset()
                    self.row_check.reset()
                    payload['reason'] = f'{len(candidates)}_target_candidates'
                else:
                    box = tuple(map(int, candidates[0]))
                    book_stable = self.book_check.update((order, self.colour), box)
                    valid = column_stable and book_stable
                    row = infer_row(all_books, self.colour, self.row_order)
                    if row:
                        row_stable = self.row_check.update((order, self.colour, row), box)
                    else:
                        self.row_check.reset()
                        row_stable = False
                    x, y, w, h = box
                    cv2.rectangle(output, (max(0,x-2), max(0,y-2)),
                        (min(frame.shape[1]-1,x+w+1), min(frame.shape[0]-1,y+h+1)),
                        (0, 210, 0) if valid else (0, 210, 255), 1)
                    payload['reason'] = 'confirmed' if valid else 'confirming'
                    if valid:
                        payload.update(valid=True, bbox_xywh=list(box),
                            pixel_center={'u': x+(w-1)/2, 'v': y+(h-1)/2})
                        if row_stable:
                            payload.update(row_valid=True, shelf_row=int(row))
                            self.row_pub.publish(Int32(data=int(row)))
                            self.save_image('book', frame, msg, box,
                                f'Column {self.target}, {self.colour}, row {row} ({self.row_order})')
        except Exception as error:
            self.reset()
            payload.update(valid=False, row_valid=False, pixel_center=None,
                           bbox_xywh=None, shelf_row=None, reason='processing_error')
            self.get_logger().error(str(error))
        self.publish_payload(payload)
        text = (f'Column {self.target}, {self.colour}: {payload["reason"]}; '
                f'row {payload["shelf_row"] if payload["row_valid"] else "unknown"}')
        self.report(text)
        if output is not None:
            output = cv2.copyMakeBorder(output, 0, 30, 0, 0,
                cv2.BORDER_CONSTANT, value=(255, 255, 255))
            cv2.putText(output, text, (5, output.shape[0]-10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.40, (0, 0, 0), 1)
            annotated = self.bridge.cv2_to_imgmsg(output, 'bgr8')
            annotated.header = msg.header
            self.images.publish(annotated)


def main():
    rclpy.init()
    node = None
    try:
        node = BookVision()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
