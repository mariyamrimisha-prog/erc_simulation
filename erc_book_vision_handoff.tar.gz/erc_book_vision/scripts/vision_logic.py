"""Pure row ordering and temporal checks, independent of ROS and OpenCV."""


def infer_row(books_by_colour, target_colour, order='top_to_bottom'):
    if order not in ('top_to_bottom', 'bottom_to_top'):
        raise ValueError('Invalid row_order')
    if set(books_by_colour) != {'red', 'green', 'blue', 'yellow'}:
        return 0
    if any(len(boxes) != 1 for boxes in books_by_colour.values()):
        return 0
    rows = sorted((boxes[0][1]+(boxes[0][3]-1)/2, colour, boxes[0][3])
                  for colour, boxes in books_by_colour.items())
    gaps = [rows[i+1][0]-rows[i][0] for i in range(3)]
    if min(gaps) < 8 or max(gaps) > 2.0*min(gaps):
        return 0
    # Each candidate must lie on a distinct level, rather than adjacent blobs.
    if any(gaps[i] < 0.5*min(rows[i][2], rows[i+1][2]) for i in range(3)):
        return 0
    rank = next(i+1 for i, item in enumerate(rows) if item[1] == target_colour)
    return rank if order == 'top_to_bottom' else 5-rank


class Confirmation:
    def __init__(self, required=3, tolerance=15):
        self.required, self.tolerance = required, tolerance
        self.reset()

    def reset(self):
        self.key, self.box, self.hits = None, None, 0

    def update(self, key, box):
        close = (self.key == key and self.box is not None and
                 max(abs(a-b) for a, b in zip(self.box, box)) <= self.tolerance)
        self.hits = min(self.required, self.hits+1) if close else 1
        self.key, self.box = key, tuple(box)
        return self.hits >= self.required
