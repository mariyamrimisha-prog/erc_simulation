#!/usr/bin/env python3
"""ERC stationary-camera perception prototype (ROS 2 Humble).

Run inside the competition container:
  python3 /opt/erc_ws/src/target_book_detector.py --ros-args \
      -p shelf_column_number:=2 -p book_colour:=red

Select /target_book/image in rqt_image_view. Green book box = confirmed
in three consecutive fresh frames. Yellow book box = pending confirmation.
This is a 2D perception test, not navigation, grasping, or a scoring submission.
Requires all five markers in the current frame. Column boundaries are estimated
from adjacent marker centres; strong perspective or close views need a more
complete shelf geometry model. Thresholds are tuned to the user's current view.
No simulator ground-truth positions are read. Templates come from model textures.
"""

from pathlib import Path
import time

import cv2
import numpy as np


def normalize(mask):
    points = cv2.findNonZero(mask)
    if points is None:
        raise ValueError('Empty digit mask')
    x, y, w, h = cv2.boundingRect(points)
    scale = min(40 / w, 48 / h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    crop = cv2.resize(mask[y:y+h, x:x+w], (nw, nh),
                      interpolation=cv2.INTER_NEAREST)
    canvas = np.zeros((56, 48), np.uint8)
    left, top = (48-nw)//2, (56-nh)//2
    canvas[top:top+nh, left:left+nw] = crop
    return canvas


def load_templates(directory):
    templates = {}
    for digit in range(1, 6):
        path = Path(directory) / f'{digit}.png'
        image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise RuntimeError(f'Cannot load {path}')
        _, mask = cv2.threshold(image, 0, 255,
                                cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        templates[digit] = normalize(mask)
    return templates


def detect_digits(hsv, templates):
    height, width = hsv.shape[:2]
    mask = cv2.inRange(hsv, (0, 0, 0), (179, 65, 115))
    bottom = int(height * 0.55)
    mask[bottom:] = 0
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
    found = []
    for index in range(1, count):
        x, y, w, h, area = map(int, stats[index])
        if area < 12 or h < 10 or h > height * 0.25:
            continue
        if not 0.18 <= w/h <= 1.25:
            continue
        if x <= 0 or y <= 0 or x+w >= width or y+h >= bottom:
            continue
        component = np.uint8(labels[y:y+h, x:x+w] == index) * 255
        candidate = cv2.copyMakeBorder(normalize(component), 3, 3, 3, 3,
                                       cv2.BORDER_CONSTANT, value=0)
        scores = sorted((float(cv2.matchTemplate(
            candidate, template, cv2.TM_CCOEFF_NORMED).max()), digit)
            for digit, template in templates.items())
        score, digit = scores[-1]
        if score < (0.60 if digit == 5 else 0.68):
            continue
        if score - scores[-2][0] < 0.07:
            continue
        found.append((digit, x, y, w, h, score))
    return sorted(found, key=lambda item: item[1])


def column_region(markers, target, width, height):
    # Missing/duplicate IDs must not silently widen a column into its neighbour.
    if len(markers) != 5 or {m[0] for m in markers} != set(range(1, 6)):
        return None
    markers = sorted(markers, key=lambda m: m[1])
    centres = [m[1] + m[3]/2 for m in markers]
    gaps = np.diff(centres)
    if min(gaps) < 10 or max(gaps) > 2 * min(gaps):
        return None
    ys = [m[2] + m[4]/2 for m in markers]
    residual = np.array(ys) - np.polyval(np.polyfit(centres, ys, 1), centres)
    if max(abs(residual)) > max(m[4] for m in markers) * 0.6:
        return None
    i = next(i for i, m in enumerate(markers) if m[0] == target)
    left = ((centres[i-1] + centres[i])/2 if i else centres[0]-gaps[0]/2)
    right = ((centres[i] + centres[i+1])/2 if i < 4 else centres[4]+gaps[-1]/2)
    top = max(m[2]+m[4] for m in markers) + 2
    return max(0, int(left)), min(height-1, top), min(width, int(right)), height


def find_books(hsv, region, colour):
    ranges = {'red': [(0, 10), (170, 179)], 'yellow': [(20, 38)],
              'green': [(40, 85)], 'blue': [(95, 135)]}
    left, top, right, bottom = region
    roi = hsv[top:bottom, left:right]
    mask = np.zeros(roi.shape[:2], np.uint8)
    for low, high in ranges[colour]:
        mask |= cv2.inRange(roi, (low, 100, 60), (high, 255, 255))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_SIMPLE)
    books = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if cv2.contourArea(contour) < 15 or h < 8 or w < 2 or h/w < 1.2:
            continue
        if x <= 0 or x+w >= right-left or y <= 0 or y+h >= bottom-top:
            continue
        books.append((x+left, y+top, w, h))
    return books


def main():
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge

    class Detector(Node):
        def __init__(self):
            super().__init__('target_book_detector')
            self.declare_parameter('shelf_column_number', 2)
            self.declare_parameter('book_colour', 'red')
            self.declare_parameter('template_dir',
                '/opt/erc_ws/src/erc_description/models/number_marker/textures')
            self.target = self.get_parameter('shelf_column_number').value
            self.colour = self.get_parameter('book_colour').value.lower()
            if self.target not in range(1, 6) or self.colour not in (
                    'red', 'blue', 'green', 'yellow'):
                raise ValueError('Use shelf_column_number 1-5 and red/blue/green/yellow')
            self.templates = load_templates(self.get_parameter('template_dir').value)
            self.bridge = CvBridge()
            self.previous = None
            self.hits = 0
            self.last_frame = time.monotonic()
            self.last_stamp = None
            self.last_status = None
            self.pub = self.create_publisher(Image, '/target_book/image', 1)
            self.sub = self.create_subscription(Image,
                '/head_front_camera/head_front_camera/color/image_raw',
                self.process, qos_profile_sensor_data)
            self.timer = self.create_timer(2.0, self.watchdog)
            self.get_logger().info(
                f'Target: column {self.target}, {self.colour}. View /target_book/image')

        def report(self, text):
            if text != self.last_status:
                self.get_logger().info(text)
                self.last_status = text

        def watchdog(self):
            if time.monotonic() - self.last_frame > 5:
                self.previous, self.hits = None, 0
                self.report('No fresh camera image for over 5 seconds; confirmation cleared.')

        def process(self, msg):
            try:
                stamp = (msg.header.stamp.sec, msg.header.stamp.nanosec)
                if stamp == self.last_stamp:
                    return
                now = time.monotonic()
                if now - self.last_frame > 5:
                    self.previous, self.hits = None, 0
                self.last_stamp, self.last_frame = stamp, now
                frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
                output = frame.copy()
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                markers = detect_digits(hsv, self.templates)
                for digit, x, y, w, h, score in markers:
                    cv2.rectangle(output, (x, y), (x+w, y+h), (0, 180, 0), 1)
                region = column_region(markers, self.target, frame.shape[1], frame.shape[0])
                books = []
                status = f'Waiting for 5 unique shelf labels; found {[m[0] for m in markers]}'
                if region is not None:
                    left, top, right, bottom = region
                    cv2.rectangle(output, (left, top), (right-1, bottom-1), (255, 180, 0), 2)
                    books = find_books(hsv, region, self.colour)
                    status = f'Column {self.target}: {len(books)} {self.colour} candidates'
                if len(books) == 1:
                    book = books[0]
                    consistent = (self.previous is not None and
                        max(abs(a-b) for a, b in zip(book, self.previous)) <= 15)
                    self.hits = min(3, self.hits+1) if consistent else 1
                    self.previous = book
                    x, y, w, h = book
                    confirmed = self.hits >= 3
                    colour = (0, 220, 0) if confirmed else (0, 220, 255)
                    cv2.rectangle(output, (x, y), (x+w, y+h), colour, 3)
                    status = (f'{"CONFIRMED" if confirmed else "CHECKING"}: '
                              f'column {self.target}, {self.colour} ({self.hits}/3)')
                else:
                    self.previous, self.hits = None, 0
                self.report(status)
                # Append a status strip instead of covering the number markers.
                output = cv2.copyMakeBorder(output, 0, 30, 0, 0,
                    cv2.BORDER_CONSTANT, value=(255, 255, 255))
                cv2.putText(output, status, (5, output.shape[0]-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 0, 0), 1)
                annotated = self.bridge.cv2_to_imgmsg(output, 'bgr8')
                annotated.header = msg.header
                self.pub.publish(annotated)
            except Exception as error:
                self.previous, self.hits = None, 0
                self.get_logger().error(f'Processing failed: {error}')

    rclpy.init()
    node = None
    try:
        node = Detector()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
