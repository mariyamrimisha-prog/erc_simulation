# ERC Member 1: Book Vision

Perception package for the existing ERC 2026 simulation. It identifies the requested shelf label and coloured book using camera pixels and the supplied digit templates. It does not move the robot, calculate depth, or grasp books. Include this launch from your team's complete solution later.

## Install and run

Extract this ZIP in Ubuntu into `~/Downloads/erc_sim_2026-1.0.3/src`. The resulting path must be `src/erc_book_vision/package.xml` (avoid an extra nested folder).

Keep Gazebo running. Stop the previous target-book and shelf-number detector processes with Ctrl+C in their own terminals.

In a new Ubuntu terminal:

```bash
cd ~/Downloads/erc_sim_2026-1.0.3
./docker/attach.sh
```

At the container prompt `root@ubuntu22:/opt/erc_ws#`:

```bash
cd /opt/erc_ws
source /opt/ros/humble/setup.bash
source install/setup.bash
colcon build --packages-select erc_book_vision
source install/setup.bash
cd /opt/erc_ws/src/erc_book_vision
ros2 launch erc_book_vision solution.launch.py shelf_column_number:=4 book_colour:=blue
```

Leave that terminal running. Select `/book_vision/image` in the image viewer. Saved evidence appears in `src/erc_book_vision/erc_images` on Ubuntu. Launching from a different directory changes the default evidence location; pass an absolute `evidence_dir:=...` when integrating with your team.

In another attached container terminal:

```bash
source /opt/erc_ws/install/setup.bash
ros2 topic echo /book_vision/detection --once
ros2 topic echo /erc/shelf_column_identification --once
ros2 topic echo /erc/shelf_row_identification --once
```

Each echo waits for a message. If the requested feature is not confirmed, its scoring topic may not publish. Stop an echo with Ctrl+C if needed.

Stop and relaunch the vision node to change the request. Example:

```bash
ros2 launch erc_book_vision solution.launch.py shelf_column_number:=2 book_colour:=red
```

## Row numbering assumption

The default is **top occupied book level = 1, bottom occupied book level = 4**. Empty shelf spaces are not counted. This is an implementation assumption, not a verified organizer numbering convention. Confirm the convention with your team/organizers before scoring. Reverse it with `row_order:=bottom_to_top` if required.

Rows are inferred only when exactly one book of each of the four colours is detected in the column, with four sufficiently separated, approximately evenly spaced vertical centres. Otherwise `row_valid` is false and no row score is published. A book pixel may still be valid while its row remains unknown.

## Member 4 handoff

`/book_vision/detection` is `std_msgs/msg/String` containing JSON, published for each new processed camera frame. This is our team interface, not an organizer-defined message. Parse the message's `data` as JSON.

| Field | Meaning |
|---|---|
| `schema_version` | 1 |
| `run_id` | Changes on node start or simulation timestamp reset |
| `header.stamp` | Original RGB frame timestamp: `sec`, `nanosec` |
| `header.frame_id` | Original RGB camera frame |
| `image_width`, `image_height` | Original RGB dimensions |
| `shelf_column_number`, `book_colour` | Requested identity, even when detection is invalid |
| `valid` | True only after three consistent detections |
| `pixel_center` | `{u, v}` in original RGB pixels, or null |
| `bbox_xywh` | `[x, y, width, height]` for the book, or null |
| `column_bbox_xywh` | Estimated column region, including its label |
| `row_valid`, `shelf_row` | Separately confirmed row, or false/null |
| `row_order` | Numbering convention used |
| `label_similarity` | Template similarity, not a calibrated probability |
| `reason` | Confirmation state or failure reason |

Member 4 must use only `valid: true`, match the original camera timestamp to depth, and reject stale messages. Coordinates belong to the original RGB image, not a resized viewer screenshot. The annotated image has an extra footer and should not be used for RGB-D registration. This node does not align RGB and depth; their measured 15 mm frame offset still needs handling by Member 4.

Lost or ambiguous detections immediately clear pixel outputs. A steady-clock watchdog invalidates the last detection after five seconds without a new camera timestamp. The scoring Int32 messages do not carry validity or timestamps; use the JSON interface for control.

## Outputs and evidence

- `/book_vision/image`: annotated `sensor_msgs/msg/Image`.
- `/book_vision/detection`: JSON handoff described above.
- `/erc/shelf_column_identification`: confirmed requested label, `std_msgs/msg/Int32`.
- `/erc/shelf_row_identification`: confirmed row, `std_msgs/msg/Int32`.
- `erc_images`: one column image and one book/row image per run after confirmation, with camera and UTC timestamps. Evidence-saving failures are logged and retried. Use `save_evidence:=false` during tests if desired.

## Limits and checks

All five shelf labels must be visible and recognized in the same frame. Column boundaries are estimated from neighbouring label centres, not a full shelf geometry model. Strong perspective, cropped labels, duplicate colour candidates, or occluded books can prevent confirmation. Navigation/head positioning must supply a suitable view. No shelf order or target location is hard-coded.

The template helper is retained from the detector already tested in your simulation. This package has been syntax-checked and its independent row/confirmation logic tested; live ROS execution must be checked in your container.

Test every colour in each column, then move the camera away and verify `valid` becomes false. Check a saved evidence image and compare published pixels against the original camera frame before handing outputs to Member 4. Do not loosen thresholds simply to force a confirmation.
